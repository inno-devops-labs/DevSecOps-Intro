#!/bin/bash
echo "Welcome to my-cool-tool installer"
echo "Running setup..."
